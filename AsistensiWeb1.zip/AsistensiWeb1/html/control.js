var namaUniversitas = document.getElementsByName("univ").values;
var fakultas = document.getElementsByName("fklts").values;
var noHp = document.getElementsByName("noHp").values;
var sosMed = document.getElementsByName("sosMed").values;
var JenisKelamin = document.getElementsByName("jk").values;
var names = document.getElementsByName("namaLengkap").values;
var animeFavorit = document.getElementsByName("animeFavorit").values;
var gendreFavorit = document.getElementsByName("gendreFavorit").values;
var wifu = document.getElementsByName("wifu").values;
var karakterKesukaan = document.getElementsByName("karakterFavorit").values;
var pin = document.getElementsByName("id").values;


function validationDaftar(){
    if(names == null || names == " "){
        alert('nama tidak boleh kosong')
    }else if (namaUniversitas == null || namaUniversitas == " "){
        alert('nama universitas tidak boleh kosong')
    }else if (fakultas == null || fakultas == " "){
        alert('nama fakultas tidak boleh kosong')
    }else if (noHp == null || noHp == " "){
        alert('nomor wa tidak boleh kosong')
    }else if (sosMed == null || sosMed == " "){
        alert('sosial media tidak boleh kosong')
    }else if (JenisKelamin == null || JenisKelamin == " "){
        alert('jenis kelamin tidak boleh kosong')
    }else if (animeFavorit == null || animeFavorit == " "){
        alert('nama anime favorit tidak boleh kosong')
    }else if (gendreFavorit == null || gendreFavorit == " "){
        alert('nama gendre favorit tidak boleh kosong')
    }else if (wifu == null || wifu == " "){
        alert('nama wifu tidak boleh kosong')
    }else if (karakterKesukaan == null || karakterKesukaan == " "){
        alert('nama karakter favorit tidak boleh kosong')
    }else if (pin == null || pin == " "){
        alert('pin tidak boleh kosong')
    }
}

