<?php

include "koneksi.php";

$names = $_POST['namaLengkap'];
$namaUniversitas= $_POST['univ'];
$fakultas = $_POST['fklts'];
$noHp = $_POST['noHP'];
$sosMed = $_POST['sosMed'];
$JenisKelamin = $_POST['jk'];

$animeFavorit = $_POST['animeFavorit'];
$gendreFavorit= $_POST['gendreFavorit'];
$wifu = $_POST['wifu'];
$karakterKesukaan  = $_POST['karakterFavorit'];
$pin = $_POST['pin'];



$sql = "insert into anggota(nama, nama_universitas,jk, noHP, sosalMedia , pin, fakultas, anime_favorit,
 gendre_favorit, wifu, karakter_kesukaan) VALUES ('$names', '$namaUniversitas', '$JenisKelamin','$noHp',
 '$sosMed', '$pin','$fakultas', '$animeFavorit', '$gendreFavorit', '$wifu', '$karakterKesukaan')";
if(mysqli_query($conn, $sql)){
    echo "data berhasil disimpan";
    echo "sampai";
}else {
    echo "Error" . $sql ." ". mysqli_error($conn);
}

?>
