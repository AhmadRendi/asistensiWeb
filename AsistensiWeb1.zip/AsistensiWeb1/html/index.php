
<?php

include "koneksi.php";

$sql = "select * from anggota";
$hasil = mysqli_query($conn, $sql);
$jumlah = mysqli_num_rows($hasil);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <table align="left"  style="background-color: aliceblue" aria-setsize="100" width="50%">
        <tr>
            <td align="left">
                <h3>Formulir Pendaftaran</h3>
            </td>
        </tr>
        <form action="process.php" method="post" cellspacing="20">
            <tr>
                <td>NOMOR PENDAFTARAN</td>
            </tr>
            <tr>
                <td><input  type="text" name="id" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>NAMA LENGKAP</td>
            </tr>
            <tr>
                <td><input placeholder="NAMA LENGKAP" type="text" name="namaLengkap" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>NAMA UNIVERSITAS</td>
            </tr>
            <tr>
                <td><input placeholder="UNIVERSITAS MUSLIM INDONESIA" type="text" name="univ" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>FAKULTAS</td>
            </tr>
            <tr>
                <td><input placeholder="TEKNIK INFORMATIKA" type="text" name="fklts" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>JENIS KELAMIN</td>
            </tr>
            <tr cellspacing="2">
                <label for="jk"></label>
                    <td>
                        <input  type="radio"  id="jk" value="Pria" name="jk" > Pria
                        <input  type="radio"   id="jk" value="Wanita" name="jk"> Wanita
                    </td>
            </tr>
            <tr>
                <td>NOMOR WA</td>
            </tr>
            <tr>
                <td><input placeholder="082289094782" type="text" name="noHP" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>SOSIAL MEDIA</td>
            </tr>
            <tr>
                <td><input placeholder="INSTAGRAM" type="text" name="sosMed" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>ANIME FAVORIT</td>
            </tr>
            <tr>
                <td><input placeholder="NARUTO" type="text" name="animeFavorit" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>GENDRE FAVORIT</td>
            </tr>
            <tr>
                <td><input placeholder="ACTION" type="text" name="gendreFavorit" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>WIFU</td>
            </tr>
            <tr>
                <td><input placeholder="SAKURA HARUNO" type="text" name="wifu" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>KARAKTER FAVORIT</td>
            </tr>
            <tr>
                <td><input placeholder="RORONOA ZORO" type="text" name="karakterFavorit" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td>PIN</td>
            </tr>
            <tr>
                <td><input placeholder="99****" type="text" name="pin" size="30" style="height: 30px;"></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" value="Daftar" style="font-size: 20px;">
                    <input type="reset" value="Batal" style="font-size: 20px">
                </td>
            </tr>

        </form>
    </table>


     <table align="left" cellspacing="2" style="background-color: aliceblue" width="50%" border="1">

    <tr>
        <h3>List Pendaftar</h3>
    </tr>
    <tr>
        <td type="batton" action="daftar.html">Daftar</td>
    </tr>

        <tr>
            <th>Nama</th>
            <th>Sosial Media</th>
            <th>EDIT</th>
        </tr>

        <?php
            $i = 1;
            while($data = mysqli_fetch_array($hasil)){
                ?> 
                <tr>
                    <td><?= $data['nama']; ?></td>
                    <td><?= $data['sosalMedia']; ?></td>
                    <td action=""> 
                        <a href="edit.php?id=<?$data['id']; ?>">Edit</a>
                    </td>
                </tr>

        <?php
        $i++;
            }?>

    </table>
     
    
</body>
</html>
