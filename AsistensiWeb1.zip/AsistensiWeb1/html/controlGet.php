

<?php


include "koneksi.php";

$sql = "select * from biodata";
$hasil = mysqli_query($conn, $sql);
$jumlah = mysqli_num_rows($hasil);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<table cellpadding="2" celspacing="0" border="0">

<tr>
    <th>Nama</th>
    <th>Sosial Media</th>
</tr>

<?php
    $i = 1;
    while($data = mysqli_fetch_array($hasil)){
        ?> 
        <tr>
            <td><?= $data['name']; ?></td>
            <td><?= $data['sosMed']; ?></td>
            <td> 
                <a href="edit.php?id=<?$data['id']; ?>">Ubah</a>
                <a href="delete.php?id=<?$data['id']; ?>">Hapus</a>
            </td>
        </tr>

        <?php
        $i++;
    }?>

</table>
    
</body>
</html>