<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "asistensiweb1";

$conn = mysqli_connect($host, $username,$password, $database);


?>